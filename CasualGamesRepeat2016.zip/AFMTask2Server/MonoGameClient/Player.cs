﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MonoGameClient
{
    public class Player: GameObject
    {
        public int Score;
    }
}
